'use strict';
// Sends N requests to a running server and prints response-time statistics
// using the X-Response-Time header returned by our middleware.
const fs = require('fs');
const base = process.argv[2] || 'http://localhost:3000';
const N = Number(process.argv[3]) || 200;

(async () => {
  const times = [];
  const ids = new Set();
  for (let i = 0; i < N; i += 1) {
    const res = await fetch(`${base}/api/users`);
    await res.text();
    times.push(parseFloat(res.headers.get('x-response-time')));
    ids.add(res.headers.get('x-request-id'));
  }
  const raw = [...times];
  times.sort((a, b) => a - b);
  const pct = (p) => times[Math.min(times.length - 1, Math.floor((p / 100) * times.length))];
  const avg = times.reduce((a, b) => a + b, 0) / times.length;
  console.log(`Requests        : ${N}`);
  console.log(`Unique IDs      : ${ids.size}`);
  console.log(`Min             : ${times[0].toFixed(2)} ms`);
  console.log(`Average         : ${avg.toFixed(2)} ms`);
  console.log(`Median (p50)    : ${pct(50).toFixed(2)} ms`);
  console.log(`p95             : ${pct(95).toFixed(2)} ms`);
  console.log(`Max             : ${times[times.length - 1].toFixed(2)} ms`);
  fs.mkdirSync('out', { recursive: true });
  fs.writeFileSync('out/bench_times.json', JSON.stringify(raw));
})();
