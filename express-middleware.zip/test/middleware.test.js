const test = require('node:test');
const assert = require('node:assert');
const createApp = require('../app');

let server, base, logs;
test.before(async () => {
  logs = [];
  server = createApp((line) => logs.push(JSON.parse(line))).listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://localhost:${server.address().port}`;
});
test.after(() => server.close());

test('adds an X-Request-ID header (UUID)', async () => {
  const res = await fetch(`${base}/`);
  assert.match(res.headers.get('x-request-id'), /^[0-9a-f-]{36}$/);
});

test('every request gets a different ID', async () => {
  const a = await fetch(`${base}/`); const b = await fetch(`${base}/`);
  assert.notStrictEqual(a.headers.get('x-request-id'), b.headers.get('x-request-id'));
});

test('reuses a valid incoming X-Request-ID', async () => {
  const res = await fetch(`${base}/`, { headers: { 'X-Request-ID': 'client-abc-12345' } });
  assert.strictEqual(res.headers.get('x-request-id'), 'client-abc-12345');
});

test('replaces an unsafe incoming X-Request-ID', async () => {
  const res = await fetch(`${base}/`, { headers: { 'X-Request-ID': 'bad id!<script>' } });
  assert.notStrictEqual(res.headers.get('x-request-id'), 'bad id!<script>');
});

test('adds X-Response-Time header in ms', async () => {
  const res = await fetch(`${base}/api/users`);
  assert.match(res.headers.get('x-response-time'), /^\d+(\.\d+)?ms$/);
});

test('slow route reports at least 300ms', async () => {
  const res = await fetch(`${base}/api/slow`);
  assert.ok(parseFloat(res.headers.get('x-response-time')) >= 290);
});

test('logs method, path, status, duration and request ID', async () => {
  logs.length = 0;
  const res = await fetch(`${base}/api/users?page=2`);
  await res.text();
  await new Promise((r) => setTimeout(r, 30));
  const entry = logs[0];
  assert.strictEqual(entry.method, 'GET');
  assert.strictEqual(entry.path, '/api/users?page=2');
  assert.strictEqual(entry.status, 200);
  assert.strictEqual(entry.requestId, res.headers.get('x-request-id'));
  assert.strictEqual(typeof entry.durationMs, 'number');
});

test('404 and 500 are logged with the right status and still have headers', async () => {
  logs.length = 0;
  const r404 = await fetch(`${base}/nope`); await r404.text();
  const r500 = await fetch(`${base}/api/error`); await r500.text();
  await new Promise((r) => setTimeout(r, 30));
  assert.strictEqual(r404.status, 404); assert.strictEqual(r500.status, 500);
  assert.ok(r404.headers.get('x-request-id') && r500.headers.get('x-response-time'));
  assert.deepStrictEqual(logs.map((l) => l.status), [404, 500]);
});

test('error body contains the request ID for support tickets', async () => {
  const res = await fetch(`${base}/api/error`);
  const body = await res.json();
  assert.strictEqual(body.requestId, res.headers.get('x-request-id'));
});

test('POST creates a user (201) and logs it', async () => {
  logs.length = 0;
  const res = await fetch(`${base}/api/users`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'Meera' }),
  });
  assert.strictEqual(res.status, 201);
  assert.strictEqual((await res.json()).name, 'Meera');
  await new Promise((r) => setTimeout(r, 30));
  assert.strictEqual(logs[0].method, 'POST');
  assert.strictEqual(logs[0].status, 201);
  assert.strictEqual(logs[0].level, 'info');
});

test('validation error (400) is logged at level warn with request ID in body', async () => {
  logs.length = 0;
  const res = await fetch(`${base}/api/users`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}),
  });
  const body = await res.json();
  await new Promise((r) => setTimeout(r, 30));
  assert.strictEqual(res.status, 400);
  assert.strictEqual(body.requestId, res.headers.get('x-request-id'));
  assert.strictEqual(logs[0].level, 'warn');
});

test('malformed JSON body returns 400 and still has the headers', async () => {
  const res = await fetch(`${base}/api/users`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{bad json',
  });
  assert.strictEqual(res.status, 400);
  assert.ok(res.headers.get('x-request-id') && res.headers.get('x-response-time'));
});

test('/health is NOT logged but still has the headers', async () => {
  logs.length = 0;
  const res = await fetch(`${base}/health`); await res.text();
  await new Promise((r) => setTimeout(r, 30));
  assert.strictEqual(logs.length, 0);
  assert.ok(res.headers.get('x-request-id'));
});

test('5xx is logged at level error; slow request at level warn', async () => {
  logs.length = 0;
  const e = await fetch(`${base}/api/error`); await e.text();
  const s = await fetch(`${base}/api/slow`); await s.text();
  await new Promise((r) => setTimeout(r, 30));
  assert.strictEqual(logs.find((l) => l.path === '/api/error').level, 'error');
  assert.strictEqual(logs.find((l) => l.path === '/api/slow').level, 'warn');
});

test('async handler errors are caught (500) and logged', async () => {
  logs.length = 0;
  const res = await fetch(`${base}/api/async-error`); await res.text();
  await new Promise((r) => setTimeout(r, 30));
  assert.strictEqual(res.status, 500);
  assert.strictEqual(logs[0].status, 500);
});

test('log entry has all expected fields', async () => {
  logs.length = 0;
  const res = await fetch(`${base}/`, { headers: { 'User-Agent': 'lab-test/1.0' } }); await res.text();
  await new Promise((r) => setTimeout(r, 30));
  assert.deepStrictEqual(Object.keys(logs[0]).sort(),
    ['bytes', 'durationMs', 'level', 'method', 'path', 'requestId', 'status', 'time', 'userAgent']);
  assert.strictEqual(logs[0].userAgent, 'lab-test/1.0');
  assert.ok(logs[0].bytes > 0);
});

test('X-Powered-By header is removed', async () => {
  const res = await fetch(`${base}/`); await res.text();
  assert.strictEqual(res.headers.get('x-powered-by'), null);
});
