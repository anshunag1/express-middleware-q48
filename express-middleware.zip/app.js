'use strict';
const express = require('express');
const requestId = require('./middleware/requestId');
const responseTime = require('./middleware/responseTime');
const logger = require('./middleware/logger');

/**
 * @param {Function} [logWriter]  receives each JSON log line (default console.log)
 */
function createApp(logWriter) {
  const app = express();
  app.disable('x-powered-by');

  // Order matters: ID first, timer second, logger third, then body parser and routes.
  app.use(requestId());
  app.use(responseTime());
  app.use(logger({ write: logWriter, skip: ['/health'], slowMs: 250 }));
  app.use(express.json());

  const users = [{ id: 1, name: 'Anshu' }, { id: 2, name: 'Ravi' }, { id: 3, name: 'Sneha' }];

  app.get('/', (req, res) => res.json({ message: 'Hello from Express', requestId: req.id }));
  app.get('/health', (req, res) => res.json({ status: 'ok' }));
  app.get('/api/users', (req, res) => res.json(users));

  app.post('/api/users', (req, res) => {
    const name = req.body && req.body.name;
    if (!name || typeof name !== 'string') {
      return res.status(400).json({ error: 'name is required', requestId: req.id });
    }
    const user = { id: users.length + 1, name };
    users.push(user);
    return res.status(201).json(user);
  });

  app.get('/api/slow', (req, res) => setTimeout(() => res.json({ done: true }), 300));

  app.get('/api/error', () => { throw new Error('Something broke'); });

  // Express 5 forwards rejected promises from async handlers to the error handler.
  app.get('/api/async-error', async () => { throw new Error('Async failure'); });

  app.use((req, res) => res.status(404).json({ error: 'Not found', requestId: req.id }));

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed') {
      return res.status(400).json({ error: 'Invalid JSON body', requestId: req.id });
    }
    return res.status(500).json({ error: 'Internal Server Error', requestId: req.id });
  });

  return app;
}

module.exports = createApp;
