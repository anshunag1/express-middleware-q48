# express-request-middleware

Express middleware that (1) adds a request ID, (2) logs method/path/status/duration as JSON and (3) returns an X-Response-Time header.

    npm install
    npm start            # http://localhost:3000
    npm test

Routes: `/`, `/api/users`, `/api/slow` (300 ms), `/api/error` (500), anything else -> 404.
