'use strict';
const { randomUUID } = require('crypto');

// Accept a safe incoming ID (so IDs can be traced across services), otherwise create one.
const SAFE_ID = /^[A-Za-z0-9._-]{8,64}$/;

/**
 * @param {{ header?: string }} [options]  header name to read/write (default X-Request-ID)
 */
function requestId({ header = 'X-Request-ID' } = {}) {
  return function requestIdMiddleware(req, res, next) {
    const incoming = req.get(header);
    req.id = incoming && SAFE_ID.test(incoming) ? incoming : randomUUID();
    res.setHeader(header, req.id);
    next();
  };
}

module.exports = requestId;
