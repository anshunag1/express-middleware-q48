'use strict';

/**
 * Logs one JSON line per request AFTER the response is finished,
 * so the real status code and duration are known.
 *
 * @param {object}   [options]
 * @param {Function} [options.write]   function that receives the log line (default console.log)
 * @param {string[]} [options.skip]    paths that are NOT logged, e.g. ['/health']
 * @param {number}   [options.slowMs]  requests slower than this are logged at level "warn"
 */
function logger({ write = (line) => console.log(line), skip = [], slowMs = 250 } = {}) {
  const out = write || ((line) => console.log(line));
  return function requestLogger(req, res, next) {
    const start = req.startTime || process.hrtime.bigint();
    res.on('finish', () => {
      if (skip.includes(req.path)) return;
      const durationMs = +(Number(process.hrtime.bigint() - start) / 1e6).toFixed(2);
      let level = 'info';
      if (res.statusCode >= 500) level = 'error';
      else if (res.statusCode >= 400 || durationMs >= slowMs) level = 'warn';

      out(JSON.stringify({
        time: new Date().toISOString(),
        level,
        requestId: req.id,
        method: req.method,
        path: req.originalUrl,
        status: res.statusCode,
        durationMs,
        bytes: Number(res.getHeader('Content-Length')) || 0,
        userAgent: req.get('User-Agent') || '-',
      }));
    });
    next();
  };
}

module.exports = logger;
