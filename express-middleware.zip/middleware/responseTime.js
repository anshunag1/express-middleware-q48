'use strict';

/**
 * Measures how long the server took and sends it in the X-Response-Time header.
 * Headers must be set before they are sent, so we wrap res.writeHead.
 * @param {{ header?: string, digits?: number }} [options]
 */
function responseTime({ header = 'X-Response-Time', digits = 2 } = {}) {
  return function responseTimeMiddleware(req, res, next) {
    const start = process.hrtime.bigint();
    req.startTime = start;
    const originalWriteHead = res.writeHead;

    res.writeHead = function (...args) {
      if (!res.headersSent && !res.getHeader(header)) {
        const ms = Number(process.hrtime.bigint() - start) / 1e6;
        res.setHeader(header, `${ms.toFixed(digits)}ms`);
      }
      return originalWriteHead.apply(this, args);
    };
    next();
  };
}

module.exports = responseTime;
